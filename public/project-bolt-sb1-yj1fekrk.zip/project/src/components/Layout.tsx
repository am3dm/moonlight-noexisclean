import { useState } from 'react';
import { useAuth } from '../contexts/AuthContext';
import {
  LayoutDashboard,
  ShoppingCart,
  Package,
  Users,
  TrendingUp,
  Settings,
  LogOut,
  Menu,
  X,
  Store,
  Truck,
  BarChart3,
} from 'lucide-react';

interface LayoutProps {
  children: React.ReactNode;
  currentPage: string;
  onNavigate: (page: string) => void;
}

export default function Layout({ children, currentPage, onNavigate }: LayoutProps) {
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const { profile, signOut } = useAuth();

  const navigation = [
    { name: 'لوحة التحكم', icon: LayoutDashboard, page: 'dashboard', roles: ['admin', 'store_manager', 'cashier'] },
    { name: 'نقطة البيع', icon: ShoppingCart, page: 'pos', roles: ['admin', 'store_manager', 'cashier'] },
    { name: 'المنتجات', icon: Package, page: 'products', roles: ['admin', 'store_manager'] },
    { name: 'العملاء', icon: Users, page: 'customers', roles: ['admin', 'store_manager', 'cashier'] },
    { name: 'الموردين', icon: Truck, page: 'suppliers', roles: ['admin', 'store_manager'] },
    { name: 'فواتير الشراء', icon: TrendingUp, page: 'purchases', roles: ['admin', 'store_manager'] },
    { name: 'التقارير', icon: BarChart3, page: 'reports', roles: ['admin', 'store_manager'] },
    { name: 'الفروع', icon: Store, page: 'branches', roles: ['admin'] },
    { name: 'الإعدادات', icon: Settings, page: 'settings', roles: ['admin'] },
  ];

  const filteredNavigation = navigation.filter((item) =>
    profile?.role ? item.roles.includes(profile.role) : false
  );

  const handleSignOut = async () => {
    try {
      await signOut();
    } catch (error) {
      console.error('Error signing out:', error);
    }
  };

  const getRoleName = (role: string) => {
    const roleNames: { [key: string]: string } = {
      admin: 'مدير النظام',
      store_manager: 'مدير المخزن',
      cashier: 'كاشير',
    };
    return roleNames[role] || role;
  };

  return (
    <div className="min-h-screen bg-gray-50" dir="rtl">
      <div className="fixed top-0 right-0 left-0 bg-white shadow-sm z-10">
        <div className="flex items-center justify-between px-4 py-3">
          <button
            onClick={() => setSidebarOpen(!sidebarOpen)}
            className="p-2 rounded-lg hover:bg-gray-100 transition lg:hidden"
          >
            {sidebarOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
          </button>

          <div className="flex items-center gap-3">
            <div className="bg-blue-600 p-2 rounded-lg">
              <ShoppingCart className="w-6 h-6 text-white" />
            </div>
            <div>
              <h1 className="text-lg font-bold text-gray-900">نظام نقاط البيع</h1>
              <p className="text-xs text-gray-500">Smart Retail POS</p>
            </div>
          </div>

          <div className="flex items-center gap-4">
            <div className="text-right hidden sm:block">
              <p className="text-sm font-semibold text-gray-900">{profile?.full_name}</p>
              <p className="text-xs text-gray-500">{profile?.role && getRoleName(profile.role)}</p>
            </div>
            <button
              onClick={handleSignOut}
              className="p-2 rounded-lg hover:bg-red-50 text-red-600 transition"
              title="تسجيل الخروج"
            >
              <LogOut className="w-5 h-5" />
            </button>
          </div>
        </div>
      </div>

      <div className="pt-16 flex">
        <aside
          className={`fixed right-0 top-16 bottom-0 w-64 bg-white shadow-lg transform transition-transform duration-300 z-20 ${
            sidebarOpen ? 'translate-x-0' : 'translate-x-full lg:translate-x-0'
          }`}
        >
          <nav className="p-4 space-y-2 overflow-y-auto h-full">
            {filteredNavigation.map((item) => (
              <button
                key={item.page}
                onClick={() => {
                  onNavigate(item.page);
                  setSidebarOpen(false);
                }}
                className={`w-full flex items-center gap-3 px-4 py-3 rounded-lg transition ${
                  currentPage === item.page
                    ? 'bg-blue-600 text-white'
                    : 'text-gray-700 hover:bg-gray-100'
                }`}
              >
                <item.icon className="w-5 h-5 flex-shrink-0" />
                <span className="font-medium">{item.name}</span>
              </button>
            ))}
          </nav>
        </aside>

        {sidebarOpen && (
          <div
            className="fixed inset-0 bg-black bg-opacity-50 z-10 lg:hidden"
            onClick={() => setSidebarOpen(false)}
          />
        )}

        <main className="flex-1 lg:mr-64 p-6">
          {children}
        </main>
      </div>
    </div>
  );
}
