/*
  # إنشاء نظام نقاط البيع والمخازن المتكامل
  
  ## الجداول الجديدة:
  
  ### 1. branches (الفروع)
    - `id` (uuid, primary key)
    - `name` (text) - اسم الفرع
    - `location` (text) - العنوان
    - `phone` (text) - رقم الهاتف
    - `is_active` (boolean) - حالة التفعيل
    - `created_at` (timestamptz)
  
  ### 2. categories (التصنيفات)
    - `id` (serial, primary key)
    - `name` (text) - اسم التصنيف
    - `description` (text) - الوصف
    - `vat_rate` (decimal) - نسبة الضريبة (0 للإعفاء)
    - `created_at` (timestamptz)
  
  ### 3. suppliers (الموردين)
    - `id` (serial, primary key)
    - `name` (text) - اسم المورد
    - `company_name` (text) - اسم الشركة
    - `phone` (text)
    - `email` (text)
    - `address` (text)
    - `credit_limit` (decimal) - حد الدين المسموح
    - `current_balance` (decimal) - الرصيد الحالي (موجب = لنا، سالب = علينا)
    - `created_at` (timestamptz)
  
  ### 4. customers (العملاء)
    - `id` (serial, primary key)
    - `name` (text) - الاسم
    - `phone` (text)
    - `email` (text)
    - `address` (text)
    - `credit_limit` (decimal) - حد الدين المسموح
    - `current_balance` (decimal) - الرصيد الحالي (موجب = عليه، سالب = له)
    - `loyalty_points` (integer) - نقاط الولاء
    - `created_at` (timestamptz)
  
  ### 5. products (المنتجات)
    - `id` (serial, primary key)
    - `name` (text) - اسم المنتج
    - `barcode` (text, unique) - الباركود
    - `category_id` (integer) - التصنيف
    - `supplier_id` (integer) - المورد الافتراضي
    - `cost_price` (decimal) - سعر الشراء
    - `selling_price` (decimal) - سعر البيع
    - `stock_quantity` (decimal) - الكمية المتوفرة
    - `min_stock_level` (decimal) - الحد الأدنى للتنبيه
    - `unit` (text) - وحدة القياس (قطعة، كرتونة، كيلو)
    - `image_url` (text) - صورة المنتج
    - `expiry_date` (date) - تاريخ الصلاحية
    - `is_active` (boolean) - حالة التفعيل
    - `branch_id` (uuid) - الفرع
    - `created_at` (timestamptz)
  
  ### 6. sales_invoices (فواتير البيع)
    - `id` (text, primary key) - معرف الفاتورة (SA-2024-001)
    - `cashier_id` (uuid) - الكاشير
    - `customer_id` (integer) - العميل (0 للزبون العابر)
    - `branch_id` (uuid) - الفرع
    - `subtotal` (decimal) - المجموع الفرعي
    - `discount_amount` (decimal) - الخصم
    - `discount_percent` (decimal) - نسبة الخصم
    - `vat_amount` (decimal) - الضريبة
    - `total` (decimal) - المجموع الكلي
    - `paid_amount` (decimal) - المبلغ المدفوع
    - `change_amount` (decimal) - الباقي
    - `payment_method` (text) - طريقة الدفع (cash, card, credit)
    - `is_credit` (boolean) - بيع آجل؟
    - `notes` (text) - ملاحظات
    - `status` (text) - الحالة (completed, returned, cancelled)
    - `created_at` (timestamptz)
  
  ### 7. sale_items (عناصر الفاتورة)
    - `id` (serial, primary key)
    - `invoice_id` (text) - رقم الفاتورة
    - `product_id` (integer) - المنتج
    - `product_name` (text) - اسم المنتج (snapshot)
    - `quantity` (decimal) - الكمية
    - `unit_price` (decimal) - سعر الوحدة
    - `unit_cost` (decimal) - تكلفة الوحدة (لحساب الربح)
    - `discount_amount` (decimal) - الخصم
    - `vat_rate` (decimal) - نسبة الضريبة
    - `vat_amount` (decimal) - مبلغ الضريبة
    - `total` (decimal) - المجموع
    - `created_at` (timestamptz)
  
  ### 8. purchase_invoices (فواتير الشراء)
    - `id` (text, primary key) - معرف الفاتورة (PU-2024-001)
    - `supplier_id` (integer) - المورد
    - `branch_id` (uuid) - الفرع
    - `user_id` (uuid) - المستخدم الذي أدخل الفاتورة
    - `invoice_number` (text) - رقم فاتورة المورد
    - `subtotal` (decimal) - المجموع
    - `discount_amount` (decimal) - الخصم
    - `total` (decimal) - الصافي
    - `paid_amount` (decimal) - المدفوع
    - `remaining_amount` (decimal) - الباقي
    - `payment_method` (text) - طريقة الدفع
    - `notes` (text)
    - `status` (text) - completed, cancelled
    - `created_at` (timestamptz)
  
  ### 9. purchase_items (عناصر فواتير الشراء)
    - `id` (serial, primary key)
    - `invoice_id` (text) - رقم الفاتورة
    - `product_id` (integer) - المنتج
    - `quantity` (decimal) - الكمية
    - `unit_cost` (decimal) - سعر الشراء
    - `total` (decimal) - المجموع
    - `expiry_date` (date) - تاريخ الصلاحية
    - `created_at` (timestamptz)
  
  ### 10. inventory_logs (سجل حركة المخزون)
    - `id` (serial, primary key)
    - `product_id` (integer) - المنتج
    - `branch_id` (uuid) - الفرع
    - `quantity_change` (decimal) - التغيير (موجب للشراء، سالب للبيع)
    - `quantity_before` (decimal) - الكمية قبل
    - `quantity_after` (decimal) - الكمية بعد
    - `transaction_type` (text) - sale, purchase, adjustment, return, waste
    - `reference_id` (text) - رقم المرجع (رقم الفاتورة)
    - `user_id` (uuid) - المستخدم
    - `notes` (text)
    - `created_at` (timestamptz)
  
  ### 11. audit_logs (سجل التدقيق)
    - `id` (serial, primary key)
    - `user_id` (uuid) - المستخدم
    - `action` (text) - الإجراء (INSERT, UPDATE, DELETE)
    - `table_name` (text) - اسم الجدول
    - `record_id` (text) - معرف السجل
    - `old_values` (jsonb) - القيم القديمة
    - `new_values` (jsonb) - القيم الجديدة
    - `ip_address` (text) - عنوان IP
    - `created_at` (timestamptz)
  
  ### 12. user_profiles (ملفات المستخدمين)
    - `id` (uuid, primary key) - مرتبط بـ auth.users
    - `full_name` (text) - الاسم الكامل
    - `role` (text) - admin, store_manager, cashier
    - `branch_id` (uuid) - الفرع
    - `phone` (text)
    - `is_active` (boolean) - حالة التفعيل
    - `created_at` (timestamptz)
  
  ## الأمان:
    - تفعيل RLS على جميع الجداول
    - سياسات وصول حسب الصلاحيات
    - حماية البيانات الحساسة
*/

-- إنشاء جدول الفروع
CREATE TABLE IF NOT EXISTS branches (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  location text,
  phone text,
  is_active boolean DEFAULT true,
  created_at timestamptz DEFAULT now()
);

-- إنشاء جدول التصنيفات
CREATE TABLE IF NOT EXISTS categories (
  id serial PRIMARY KEY,
  name text NOT NULL,
  description text,
  vat_rate decimal(5,2) DEFAULT 0,
  created_at timestamptz DEFAULT now()
);

-- إنشاء جدول الموردين
CREATE TABLE IF NOT EXISTS suppliers (
  id serial PRIMARY KEY,
  name text NOT NULL,
  company_name text,
  phone text,
  email text,
  address text,
  credit_limit decimal(12,2) DEFAULT 0,
  current_balance decimal(12,2) DEFAULT 0,
  created_at timestamptz DEFAULT now()
);

-- إنشاء جدول العملاء
CREATE TABLE IF NOT EXISTS customers (
  id serial PRIMARY KEY,
  name text NOT NULL,
  phone text,
  email text,
  address text,
  credit_limit decimal(12,2) DEFAULT 0,
  current_balance decimal(12,2) DEFAULT 0,
  loyalty_points integer DEFAULT 0,
  created_at timestamptz DEFAULT now()
);

-- إنشاء جدول المنتجات
CREATE TABLE IF NOT EXISTS products (
  id serial PRIMARY KEY,
  name text NOT NULL,
  barcode text UNIQUE,
  category_id integer REFERENCES categories(id),
  supplier_id integer REFERENCES suppliers(id),
  cost_price decimal(10,2) NOT NULL DEFAULT 0,
  selling_price decimal(10,2) NOT NULL,
  stock_quantity decimal(10,3) DEFAULT 0,
  min_stock_level decimal(10,3) DEFAULT 5,
  unit text DEFAULT 'قطعة',
  image_url text,
  expiry_date date,
  is_active boolean DEFAULT true,
  branch_id uuid REFERENCES branches(id),
  created_at timestamptz DEFAULT now()
);

-- إنشاء جدول ملفات المستخدمين
CREATE TABLE IF NOT EXISTS user_profiles (
  id uuid PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  full_name text NOT NULL,
  role text NOT NULL DEFAULT 'cashier',
  branch_id uuid REFERENCES branches(id),
  phone text,
  is_active boolean DEFAULT true,
  created_at timestamptz DEFAULT now()
);

-- إنشاء جدول فواتير البيع
CREATE TABLE IF NOT EXISTS sales_invoices (
  id text PRIMARY KEY,
  cashier_id uuid REFERENCES auth.users(id),
  customer_id integer DEFAULT 0,
  branch_id uuid REFERENCES branches(id),
  subtotal decimal(12,2) DEFAULT 0,
  discount_amount decimal(12,2) DEFAULT 0,
  discount_percent decimal(5,2) DEFAULT 0,
  vat_amount decimal(12,2) DEFAULT 0,
  total decimal(12,2) NOT NULL,
  paid_amount decimal(12,2) DEFAULT 0,
  change_amount decimal(12,2) DEFAULT 0,
  payment_method text DEFAULT 'cash',
  is_credit boolean DEFAULT false,
  notes text,
  status text DEFAULT 'completed',
  created_at timestamptz DEFAULT now()
);

-- إنشاء جدول عناصر الفاتورة
CREATE TABLE IF NOT EXISTS sale_items (
  id serial PRIMARY KEY,
  invoice_id text REFERENCES sales_invoices(id) ON DELETE CASCADE,
  product_id integer REFERENCES products(id),
  product_name text NOT NULL,
  quantity decimal(10,3) NOT NULL,
  unit_price decimal(10,2) NOT NULL,
  unit_cost decimal(10,2) NOT NULL,
  discount_amount decimal(10,2) DEFAULT 0,
  vat_rate decimal(5,2) DEFAULT 0,
  vat_amount decimal(10,2) DEFAULT 0,
  total decimal(12,2) NOT NULL,
  created_at timestamptz DEFAULT now()
);

-- إنشاء جدول فواتير الشراء
CREATE TABLE IF NOT EXISTS purchase_invoices (
  id text PRIMARY KEY,
  supplier_id integer REFERENCES suppliers(id),
  branch_id uuid REFERENCES branches(id),
  user_id uuid REFERENCES auth.users(id),
  invoice_number text,
  subtotal decimal(12,2) DEFAULT 0,
  discount_amount decimal(12,2) DEFAULT 0,
  total decimal(12,2) NOT NULL,
  paid_amount decimal(12,2) DEFAULT 0,
  remaining_amount decimal(12,2) DEFAULT 0,
  payment_method text DEFAULT 'cash',
  notes text,
  status text DEFAULT 'completed',
  created_at timestamptz DEFAULT now()
);

-- إنشاء جدول عناصر فواتير الشراء
CREATE TABLE IF NOT EXISTS purchase_items (
  id serial PRIMARY KEY,
  invoice_id text REFERENCES purchase_invoices(id) ON DELETE CASCADE,
  product_id integer REFERENCES products(id),
  quantity decimal(10,3) NOT NULL,
  unit_cost decimal(10,2) NOT NULL,
  total decimal(12,2) NOT NULL,
  expiry_date date,
  created_at timestamptz DEFAULT now()
);

-- إنشاء جدول حركة المخزون
CREATE TABLE IF NOT EXISTS inventory_logs (
  id serial PRIMARY KEY,
  product_id integer REFERENCES products(id),
  branch_id uuid REFERENCES branches(id),
  quantity_change decimal(10,3) NOT NULL,
  quantity_before decimal(10,3) NOT NULL,
  quantity_after decimal(10,3) NOT NULL,
  transaction_type text NOT NULL,
  reference_id text,
  user_id uuid REFERENCES auth.users(id),
  notes text,
  created_at timestamptz DEFAULT now()
);

-- إنشاء جدول التدقيق
CREATE TABLE IF NOT EXISTS audit_logs (
  id serial PRIMARY KEY,
  user_id uuid REFERENCES auth.users(id),
  action text NOT NULL,
  table_name text NOT NULL,
  record_id text,
  old_values jsonb,
  new_values jsonb,
  ip_address text,
  created_at timestamptz DEFAULT now()
);

-- إنشاء الفهارس لتحسين الأداء
CREATE INDEX IF NOT EXISTS idx_products_barcode ON products(barcode);
CREATE INDEX IF NOT EXISTS idx_products_name ON products USING GIN (to_tsvector('arabic', name));
CREATE INDEX IF NOT EXISTS idx_products_category ON products(category_id);
CREATE INDEX IF NOT EXISTS idx_products_branch ON products(branch_id);
CREATE INDEX IF NOT EXISTS idx_sales_invoices_date ON sales_invoices(created_at);
CREATE INDEX IF NOT EXISTS idx_sales_invoices_cashier ON sales_invoices(cashier_id);
CREATE INDEX IF NOT EXISTS idx_sale_items_invoice ON sale_items(invoice_id);
CREATE INDEX IF NOT EXISTS idx_inventory_logs_product ON inventory_logs(product_id);
CREATE INDEX IF NOT EXISTS idx_inventory_logs_date ON inventory_logs(created_at);

-- تفعيل RLS على جميع الجداول
ALTER TABLE branches ENABLE ROW LEVEL SECURITY;
ALTER TABLE categories ENABLE ROW LEVEL SECURITY;
ALTER TABLE suppliers ENABLE ROW LEVEL SECURITY;
ALTER TABLE customers ENABLE ROW LEVEL SECURITY;
ALTER TABLE products ENABLE ROW LEVEL SECURITY;
ALTER TABLE user_profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE sales_invoices ENABLE ROW LEVEL SECURITY;
ALTER TABLE sale_items ENABLE ROW LEVEL SECURITY;
ALTER TABLE purchase_invoices ENABLE ROW LEVEL SECURITY;
ALTER TABLE purchase_items ENABLE ROW LEVEL SECURITY;
ALTER TABLE inventory_logs ENABLE ROW LEVEL SECURITY;
ALTER TABLE audit_logs ENABLE ROW LEVEL SECURITY;

-- سياسات الأمان: المديرون يمكنهم رؤية كل شيء
CREATE POLICY "Admins can view all branches"
  ON branches FOR SELECT
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM user_profiles
      WHERE user_profiles.id = auth.uid()
      AND user_profiles.role = 'admin'
    )
  );

CREATE POLICY "Admins can manage branches"
  ON branches FOR ALL
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM user_profiles
      WHERE user_profiles.id = auth.uid()
      AND user_profiles.role = 'admin'
    )
  );

-- سياسات التصنيفات: المستخدمون المصرح لهم يمكنهم القراءة
CREATE POLICY "Authenticated users can view categories"
  ON categories FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "Admins and managers can manage categories"
  ON categories FOR ALL
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM user_profiles
      WHERE user_profiles.id = auth.uid()
      AND user_profiles.role IN ('admin', 'store_manager')
    )
  );

-- سياسات الموردين
CREATE POLICY "Authenticated users can view suppliers"
  ON suppliers FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "Admins and managers can manage suppliers"
  ON suppliers FOR ALL
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM user_profiles
      WHERE user_profiles.id = auth.uid()
      AND user_profiles.role IN ('admin', 'store_manager')
    )
  );

-- سياسات العملاء
CREATE POLICY "Authenticated users can view customers"
  ON customers FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "Authenticated users can manage customers"
  ON customers FOR ALL
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM user_profiles
      WHERE user_profiles.id = auth.uid()
    )
  );

-- سياسات المنتجات
CREATE POLICY "Authenticated users can view products"
  ON products FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "Admins and managers can manage products"
  ON products FOR ALL
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM user_profiles
      WHERE user_profiles.id = auth.uid()
      AND user_profiles.role IN ('admin', 'store_manager')
    )
  );

-- سياسات ملفات المستخدمين
CREATE POLICY "Users can view own profile"
  ON user_profiles FOR SELECT
  TO authenticated
  USING (auth.uid() = id);

CREATE POLICY "Admins can view all profiles"
  ON user_profiles FOR SELECT
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM user_profiles up
      WHERE up.id = auth.uid()
      AND up.role = 'admin'
    )
  );

CREATE POLICY "Admins can manage profiles"
  ON user_profiles FOR ALL
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM user_profiles up
      WHERE up.id = auth.uid()
      AND up.role = 'admin'
    )
  );

-- سياسات فواتير البيع
CREATE POLICY "Authenticated users can view sales"
  ON sales_invoices FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "Authenticated users can create sales"
  ON sales_invoices FOR INSERT
  TO authenticated
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM user_profiles
      WHERE user_profiles.id = auth.uid()
    )
  );

CREATE POLICY "Admins can manage sales"
  ON sales_invoices FOR ALL
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM user_profiles
      WHERE user_profiles.id = auth.uid()
      AND user_profiles.role = 'admin'
    )
  );

-- سياسات عناصر الفاتورة
CREATE POLICY "Authenticated users can view sale items"
  ON sale_items FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "Authenticated users can create sale items"
  ON sale_items FOR INSERT
  TO authenticated
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM user_profiles
      WHERE user_profiles.id = auth.uid()
    )
  );

-- سياسات فواتير الشراء
CREATE POLICY "Authenticated users can view purchases"
  ON purchase_invoices FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "Admins and managers can manage purchases"
  ON purchase_invoices FOR ALL
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM user_profiles
      WHERE user_profiles.id = auth.uid()
      AND user_profiles.role IN ('admin', 'store_manager')
    )
  );

-- سياسات عناصر فواتير الشراء
CREATE POLICY "Authenticated users can view purchase items"
  ON purchase_items FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "Admins and managers can manage purchase items"
  ON purchase_items FOR ALL
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM user_profiles
      WHERE user_profiles.id = auth.uid()
      AND user_profiles.role IN ('admin', 'store_manager')
    )
  );

-- سياسات حركة المخزون
CREATE POLICY "Authenticated users can view inventory logs"
  ON inventory_logs FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "System can create inventory logs"
  ON inventory_logs FOR INSERT
  TO authenticated
  WITH CHECK (true);

-- سياسات سجل التدقيق
CREATE POLICY "Admins can view audit logs"
  ON audit_logs FOR SELECT
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM user_profiles
      WHERE user_profiles.id = auth.uid()
      AND user_profiles.role = 'admin'
    )
  );

-- إدراج بيانات تجريبية
-- فرع افتراضي
INSERT INTO branches (id, name, location, phone)
VALUES 
  ('00000000-0000-0000-0000-000000000001', 'الفرع الرئيسي', 'بغداد - الكرادة', '07701234567')
ON CONFLICT (id) DO NOTHING;

-- تصنيفات أساسية
INSERT INTO categories (name, description, vat_rate)
VALUES 
  ('مواد غذائية', 'مواد غذائية ومشروبات', 0),
  ('منظفات', 'منظفات ومساحيق', 0),
  ('إلكترونيات', 'أجهزة إلكترونية', 0),
  ('ملابس', 'ملابس وأحذية', 0),
  ('قرطاسية', 'أدوات مكتبية ومدرسية', 0)
ON CONFLICT DO NOTHING;