import { useState, useEffect, useRef } from 'react';
import { supabase } from '../lib/supabase';
import { useAuth } from '../contexts/AuthContext';
import { Search, Plus, Minus, Trash2, ShoppingCart, Loader2, Printer } from 'lucide-react';
import type { Database } from '../lib/database.types';

type Product = Database['public']['Tables']['products']['Row'];

interface CartItem extends Product {
  cartQuantity: number;
  itemTotal: number;
}

export default function POS() {
  const { user, profile } = useAuth();
  const [products, setProducts] = useState<Product[]>([]);
  const [cart, setCart] = useState<CartItem[]>([]);
  const [searchQuery, setSearchQuery] = useState('');
  const [loading, setLoading] = useState(true);
  const [processing, setProcessing] = useState(false);
  const searchInputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    fetchProducts();
    searchInputRef.current?.focus();
  }, []);

  const fetchProducts = async () => {
    try {
      const { data, error } = await supabase
        .from('products')
        .select('*')
        .eq('is_active', true)
        .order('name');

      if (error) throw error;
      setProducts(data || []);
    } catch (error) {
      console.error('Error fetching products:', error);
    } finally {
      setLoading(false);
    }
  };

  const filteredProducts = products.filter(
    (product) =>
      product.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      product.barcode?.includes(searchQuery)
  );

  const addToCart = (product: Product) => {
    const existingItem = cart.find((item) => item.id === product.id);

    if (existingItem) {
      updateQuantity(product.id, existingItem.cartQuantity + 1);
    } else {
      const newItem: CartItem = {
        ...product,
        cartQuantity: 1,
        itemTotal: product.selling_price,
      };
      setCart([...cart, newItem]);
    }
    setSearchQuery('');
  };

  const updateQuantity = (productId: number, newQuantity: number) => {
    if (newQuantity <= 0) {
      removeFromCart(productId);
      return;
    }

    setCart(
      cart.map((item) =>
        item.id === productId
          ? {
              ...item,
              cartQuantity: newQuantity,
              itemTotal: item.selling_price * newQuantity,
            }
          : item
      )
    );
  };

  const removeFromCart = (productId: number) => {
    setCart(cart.filter((item) => item.id !== productId));
  };

  const calculateTotal = () => {
    return cart.reduce((sum, item) => sum + item.itemTotal, 0);
  };

  const completeSale = async () => {
    if (cart.length === 0) return;

    setProcessing(true);
    try {
      const invoiceId = `SA-${Date.now()}`;
      const total = calculateTotal();

      const { error: invoiceError } = await supabase.from('sales_invoices').insert({
        id: invoiceId,
        cashier_id: user?.id,
        customer_id: 0,
        branch_id: profile?.branch_id || '00000000-0000-0000-0000-000000000001',
        subtotal: total,
        total: total,
        paid_amount: total,
        payment_method: 'cash',
        status: 'completed',
      });

      if (invoiceError) throw invoiceError;

      const saleItems = cart.map((item) => ({
        invoice_id: invoiceId,
        product_id: item.id,
        product_name: item.name,
        quantity: item.cartQuantity,
        unit_price: item.selling_price,
        unit_cost: item.cost_price,
        total: item.itemTotal,
      }));

      const { error: itemsError } = await supabase.from('sale_items').insert(saleItems);

      if (itemsError) throw itemsError;

      for (const item of cart) {
        const newQuantity = item.stock_quantity - item.cartQuantity;

        await supabase
          .from('products')
          .update({ stock_quantity: newQuantity })
          .eq('id', item.id);

        await supabase.from('inventory_logs').insert({
          product_id: item.id,
          branch_id: profile?.branch_id || '00000000-0000-0000-0000-000000000001',
          quantity_change: -item.cartQuantity,
          quantity_before: item.stock_quantity,
          quantity_after: newQuantity,
          transaction_type: 'sale',
          reference_id: invoiceId,
          user_id: user?.id,
        });
      }

      alert('تمت عملية البيع بنجاح');
      setCart([]);
      fetchProducts();
    } catch (error) {
      console.error('Error completing sale:', error);
      alert('حدث خطأ أثناء إتمام عملية البيع');
    } finally {
      setProcessing(false);
    }
  };

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('ar-IQ', {
      minimumFractionDigits: 0,
      maximumFractionDigits: 0,
    }).format(amount) + ' د.ع';
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <Loader2 className="w-12 h-12 animate-spin text-blue-600" />
      </div>
    );
  }

  return (
    <div className="h-[calc(100vh-8rem)]">
      <div className="flex items-center justify-between mb-6">
        <h1 className="text-3xl font-bold text-gray-900">نقطة البيع</h1>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 h-[calc(100%-5rem)]">
        <div className="lg:col-span-2 bg-white rounded-xl shadow-sm p-6 overflow-hidden flex flex-col">
          <div className="mb-4">
            <div className="relative">
              <Search className="absolute right-3 top-3 text-gray-400 w-5 h-5" />
              <input
                ref={searchInputRef}
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="ابحث عن منتج بالاسم أو الباركود..."
                className="w-full pr-10 pl-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              />
            </div>
          </div>

          <div className="flex-1 overflow-y-auto">
            <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-3">
              {filteredProducts.map((product) => (
                <button
                  key={product.id}
                  onClick={() => addToCart(product)}
                  className="bg-white border-2 border-gray-200 rounded-lg p-3 hover:border-blue-500 transition group"
                >
                  <div className="aspect-square bg-gray-100 rounded-lg mb-2 flex items-center justify-center">
                    <Package className="w-8 h-8 text-gray-400" />
                  </div>
                  <h3 className="text-sm font-semibold text-gray-900 line-clamp-2 mb-1">
                    {product.name}
                  </h3>
                  <p className="text-blue-600 font-bold">{formatCurrency(product.selling_price)}</p>
                  <p className="text-xs text-gray-500 mt-1">
                    متوفر: {product.stock_quantity} {product.unit}
                  </p>
                </button>
              ))}
            </div>
          </div>
        </div>

        <div className="bg-white rounded-xl shadow-sm p-6 flex flex-col">
          <div className="flex items-center gap-2 mb-4 pb-4 border-b">
            <ShoppingCart className="w-6 h-6 text-blue-600" />
            <h2 className="text-xl font-bold text-gray-900">سلة المشتريات</h2>
            <span className="mr-auto bg-blue-100 text-blue-600 px-3 py-1 rounded-full text-sm font-semibold">
              {cart.length}
            </span>
          </div>

          <div className="flex-1 overflow-y-auto mb-4">
            {cart.length === 0 ? (
              <div className="text-center py-12">
                <ShoppingCart className="w-16 h-16 text-gray-300 mx-auto mb-4" />
                <p className="text-gray-500">السلة فارغة</p>
              </div>
            ) : (
              <div className="space-y-3">
                {cart.map((item) => (
                  <div key={item.id} className="bg-gray-50 rounded-lg p-3">
                    <div className="flex items-start justify-between mb-2">
                      <h3 className="font-semibold text-gray-900 text-sm flex-1">
                        {item.name}
                      </h3>
                      <button
                        onClick={() => removeFromCart(item.id)}
                        className="text-red-500 hover:text-red-700 p-1"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <button
                          onClick={() => updateQuantity(item.id, item.cartQuantity - 1)}
                          className="w-7 h-7 bg-white border border-gray-300 rounded flex items-center justify-center hover:bg-gray-50"
                        >
                          <Minus className="w-3 h-3" />
                        </button>
                        <span className="w-8 text-center font-semibold">{item.cartQuantity}</span>
                        <button
                          onClick={() => updateQuantity(item.id, item.cartQuantity + 1)}
                          className="w-7 h-7 bg-white border border-gray-300 rounded flex items-center justify-center hover:bg-gray-50"
                        >
                          <Plus className="w-3 h-3" />
                        </button>
                      </div>
                      <span className="font-bold text-blue-600">
                        {formatCurrency(item.itemTotal)}
                      </span>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>

          <div className="border-t pt-4 space-y-4">
            <div className="flex items-center justify-between text-2xl font-bold">
              <span>المجموع الكلي</span>
              <span className="text-blue-600">{formatCurrency(calculateTotal())}</span>
            </div>

            <button
              onClick={completeSale}
              disabled={cart.length === 0 || processing}
              className="w-full bg-blue-600 hover:bg-blue-700 text-white font-bold py-4 px-4 rounded-lg transition disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-2"
            >
              {processing ? (
                <>
                  <Loader2 className="w-5 h-5 animate-spin" />
                  <span>جاري المعالجة...</span>
                </>
              ) : (
                <>
                  <Printer className="w-5 h-5" />
                  <span>إتمام البيع</span>
                </>
              )}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}

function Package(props: React.SVGProps<SVGSVGElement>) {
  return (
    <svg
      {...props}
      xmlns="http://www.w3.org/2000/svg"
      width="24"
      height="24"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
    >
      <path d="m7.5 4.27 9 5.15" />
      <path d="M21 8a2 2 0 0 0-1-1.73l-7-4a2 2 0 0 0-2 0l-7 4A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.73l7 4a2 2 0 0 0 2 0l7-4A2 2 0 0 0 21 16Z" />
      <path d="m3.3 7 8.7 5 8.7-5" />
      <path d="M12 22V12" />
    </svg>
  );
}
