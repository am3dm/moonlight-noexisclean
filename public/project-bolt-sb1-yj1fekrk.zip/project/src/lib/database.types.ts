export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export interface Database {
  public: {
    Tables: {
      branches: {
        Row: {
          id: string
          name: string
          location: string | null
          phone: string | null
          is_active: boolean
          created_at: string
        }
        Insert: {
          id?: string
          name: string
          location?: string | null
          phone?: string | null
          is_active?: boolean
          created_at?: string
        }
        Update: {
          id?: string
          name?: string
          location?: string | null
          phone?: string | null
          is_active?: boolean
          created_at?: string
        }
      }
      categories: {
        Row: {
          id: number
          name: string
          description: string | null
          vat_rate: number
          created_at: string
        }
        Insert: {
          id?: number
          name: string
          description?: string | null
          vat_rate?: number
          created_at?: string
        }
        Update: {
          id?: number
          name?: string
          description?: string | null
          vat_rate?: number
          created_at?: string
        }
      }
      suppliers: {
        Row: {
          id: number
          name: string
          company_name: string | null
          phone: string | null
          email: string | null
          address: string | null
          credit_limit: number
          current_balance: number
          created_at: string
        }
        Insert: {
          id?: number
          name: string
          company_name?: string | null
          phone?: string | null
          email?: string | null
          address?: string | null
          credit_limit?: number
          current_balance?: number
          created_at?: string
        }
        Update: {
          id?: number
          name?: string
          company_name?: string | null
          phone?: string | null
          email?: string | null
          address?: string | null
          credit_limit?: number
          current_balance?: number
          created_at?: string
        }
      }
      customers: {
        Row: {
          id: number
          name: string
          phone: string | null
          email: string | null
          address: string | null
          credit_limit: number
          current_balance: number
          loyalty_points: number
          created_at: string
        }
        Insert: {
          id?: number
          name: string
          phone?: string | null
          email?: string | null
          address?: string | null
          credit_limit?: number
          current_balance?: number
          loyalty_points?: number
          created_at?: string
        }
        Update: {
          id?: number
          name?: string
          phone?: string | null
          email?: string | null
          address?: string | null
          credit_limit?: number
          current_balance?: number
          loyalty_points?: number
          created_at?: string
        }
      }
      products: {
        Row: {
          id: number
          name: string
          barcode: string | null
          category_id: number | null
          supplier_id: number | null
          cost_price: number
          selling_price: number
          stock_quantity: number
          min_stock_level: number
          unit: string
          image_url: string | null
          expiry_date: string | null
          is_active: boolean
          branch_id: string | null
          created_at: string
        }
        Insert: {
          id?: number
          name: string
          barcode?: string | null
          category_id?: number | null
          supplier_id?: number | null
          cost_price?: number
          selling_price: number
          stock_quantity?: number
          min_stock_level?: number
          unit?: string
          image_url?: string | null
          expiry_date?: string | null
          is_active?: boolean
          branch_id?: string | null
          created_at?: string
        }
        Update: {
          id?: number
          name?: string
          barcode?: string | null
          category_id?: number | null
          supplier_id?: number | null
          cost_price?: number
          selling_price?: number
          stock_quantity?: number
          min_stock_level?: number
          unit?: string
          image_url?: string | null
          expiry_date?: string | null
          is_active?: boolean
          branch_id?: string | null
          created_at?: string
        }
      }
      user_profiles: {
        Row: {
          id: string
          full_name: string
          role: 'admin' | 'store_manager' | 'cashier'
          branch_id: string | null
          phone: string | null
          is_active: boolean
          created_at: string
        }
        Insert: {
          id: string
          full_name: string
          role?: 'admin' | 'store_manager' | 'cashier'
          branch_id?: string | null
          phone?: string | null
          is_active?: boolean
          created_at?: string
        }
        Update: {
          id?: string
          full_name?: string
          role?: 'admin' | 'store_manager' | 'cashier'
          branch_id?: string | null
          phone?: string | null
          is_active?: boolean
          created_at?: string
        }
      }
      sales_invoices: {
        Row: {
          id: string
          cashier_id: string | null
          customer_id: number
          branch_id: string | null
          subtotal: number
          discount_amount: number
          discount_percent: number
          vat_amount: number
          total: number
          paid_amount: number
          change_amount: number
          payment_method: string
          is_credit: boolean
          notes: string | null
          status: string
          created_at: string
        }
        Insert: {
          id: string
          cashier_id?: string | null
          customer_id?: number
          branch_id?: string | null
          subtotal?: number
          discount_amount?: number
          discount_percent?: number
          vat_amount?: number
          total: number
          paid_amount?: number
          change_amount?: number
          payment_method?: string
          is_credit?: boolean
          notes?: string | null
          status?: string
          created_at?: string
        }
        Update: {
          id?: string
          cashier_id?: string | null
          customer_id?: number
          branch_id?: string | null
          subtotal?: number
          discount_amount?: number
          discount_percent?: number
          vat_amount?: number
          total?: number
          paid_amount?: number
          change_amount?: number
          payment_method?: string
          is_credit?: boolean
          notes?: string | null
          status?: string
          created_at?: string
        }
      }
      sale_items: {
        Row: {
          id: number
          invoice_id: string
          product_id: number | null
          product_name: string
          quantity: number
          unit_price: number
          unit_cost: number
          discount_amount: number
          vat_rate: number
          vat_amount: number
          total: number
          created_at: string
        }
        Insert: {
          id?: number
          invoice_id: string
          product_id?: number | null
          product_name: string
          quantity: number
          unit_price: number
          unit_cost: number
          discount_amount?: number
          vat_rate?: number
          vat_amount?: number
          total: number
          created_at?: string
        }
        Update: {
          id?: number
          invoice_id?: string
          product_id?: number | null
          product_name?: string
          quantity?: number
          unit_price?: number
          unit_cost?: number
          discount_amount?: number
          vat_rate?: number
          vat_amount?: number
          total?: number
          created_at?: string
        }
      }
      purchase_invoices: {
        Row: {
          id: string
          supplier_id: number | null
          branch_id: string | null
          user_id: string | null
          invoice_number: string | null
          subtotal: number
          discount_amount: number
          total: number
          paid_amount: number
          remaining_amount: number
          payment_method: string
          notes: string | null
          status: string
          created_at: string
        }
        Insert: {
          id: string
          supplier_id?: number | null
          branch_id?: string | null
          user_id?: string | null
          invoice_number?: string | null
          subtotal?: number
          discount_amount?: number
          total: number
          paid_amount?: number
          remaining_amount?: number
          payment_method?: string
          notes?: string | null
          status?: string
          created_at?: string
        }
        Update: {
          id?: string
          supplier_id?: number | null
          branch_id?: string | null
          user_id?: string | null
          invoice_number?: string | null
          subtotal?: number
          discount_amount?: number
          total?: number
          paid_amount?: number
          remaining_amount?: number
          payment_method?: string
          notes?: string | null
          status?: string
          created_at?: string
        }
      }
      purchase_items: {
        Row: {
          id: number
          invoice_id: string
          product_id: number | null
          quantity: number
          unit_cost: number
          total: number
          expiry_date: string | null
          created_at: string
        }
        Insert: {
          id?: number
          invoice_id: string
          product_id?: number | null
          quantity: number
          unit_cost: number
          total: number
          expiry_date?: string | null
          created_at?: string
        }
        Update: {
          id?: number
          invoice_id?: string
          product_id?: number | null
          quantity?: number
          unit_cost?: number
          total?: number
          expiry_date?: string | null
          created_at?: string
        }
      }
      inventory_logs: {
        Row: {
          id: number
          product_id: number | null
          branch_id: string | null
          quantity_change: number
          quantity_before: number
          quantity_after: number
          transaction_type: string
          reference_id: string | null
          user_id: string | null
          notes: string | null
          created_at: string
        }
        Insert: {
          id?: number
          product_id?: number | null
          branch_id?: string | null
          quantity_change: number
          quantity_before: number
          quantity_after: number
          transaction_type: string
          reference_id?: string | null
          user_id?: string | null
          notes?: string | null
          created_at?: string
        }
        Update: {
          id?: number
          product_id?: number | null
          branch_id?: string | null
          quantity_change?: number
          quantity_before?: number
          quantity_after?: number
          transaction_type?: string
          reference_id?: string | null
          user_id?: string | null
          notes?: string | null
          created_at?: string
        }
      }
      audit_logs: {
        Row: {
          id: number
          user_id: string | null
          action: string
          table_name: string
          record_id: string | null
          old_values: Json | null
          new_values: Json | null
          ip_address: string | null
          created_at: string
        }
        Insert: {
          id?: number
          user_id?: string | null
          action: string
          table_name: string
          record_id?: string | null
          old_values?: Json | null
          new_values?: Json | null
          ip_address?: string | null
          created_at?: string
        }
        Update: {
          id?: number
          user_id?: string | null
          action?: string
          table_name?: string
          record_id?: string | null
          old_values?: Json | null
          new_values?: Json | null
          ip_address?: string | null
          created_at?: string
        }
      }
    }
    Views: {
      [_ in never]: never
    }
    Functions: {
      [_ in never]: never
    }
    Enums: {
      [_ in never]: never
    }
  }
}
