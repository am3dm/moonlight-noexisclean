import { useEffect, useState } from 'react';
import { supabase } from '../lib/supabase';
import { TrendingUp, Package, Users, ShoppingCart, AlertTriangle } from 'lucide-react';

interface DashboardStats {
  totalProducts: number;
  lowStockProducts: number;
  totalCustomers: number;
  todaySales: number;
  todayProfit: number;
}

export default function Dashboard() {
  const [stats, setStats] = useState<DashboardStats>({
    totalProducts: 0,
    lowStockProducts: 0,
    totalCustomers: 0,
    todaySales: 0,
    todayProfit: 0,
  });
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchDashboardData();
  }, []);

  const fetchDashboardData = async () => {
    try {
      const [productsRes, customersRes, salesRes] = await Promise.all([
        supabase.from('products').select('id, stock_quantity, min_stock_level'),
        supabase.from('customers').select('id', { count: 'exact', head: true }),
        supabase
          .from('sales_invoices')
          .select('total, sale_items(unit_price, unit_cost, quantity)')
          .gte('created_at', new Date().setHours(0, 0, 0, 0))
          .eq('status', 'completed'),
      ]);

      const lowStock = productsRes.data?.filter(
        (p) => p.stock_quantity <= p.min_stock_level
      ).length || 0;

      const totalSales = salesRes.data?.reduce((sum, sale) => sum + sale.total, 0) || 0;

      const totalProfit =
        salesRes.data?.reduce((sum, sale) => {
          const saleProfit =
            sale.sale_items?.reduce((itemSum, item) => {
              return itemSum + (item.unit_price - item.unit_cost) * item.quantity;
            }, 0) || 0;
          return sum + saleProfit;
        }, 0) || 0;

      setStats({
        totalProducts: productsRes.data?.length || 0,
        lowStockProducts: lowStock,
        totalCustomers: customersRes.count || 0,
        todaySales: totalSales,
        todayProfit: totalProfit,
      });
    } catch (error) {
      console.error('Error fetching dashboard data:', error);
    } finally {
      setLoading(false);
    }
  };

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('ar-IQ', {
      minimumFractionDigits: 0,
      maximumFractionDigits: 0,
    }).format(amount) + ' د.ع';
  };

  const statCards = [
    {
      title: 'مبيعات اليوم',
      value: formatCurrency(stats.todaySales),
      icon: ShoppingCart,
      color: 'bg-blue-500',
      bgLight: 'bg-blue-50',
    },
    {
      title: 'أرباح اليوم',
      value: formatCurrency(stats.todayProfit),
      icon: TrendingUp,
      color: 'bg-green-500',
      bgLight: 'bg-green-50',
    },
    {
      title: 'إجمالي المنتجات',
      value: stats.totalProducts.toString(),
      icon: Package,
      color: 'bg-purple-500',
      bgLight: 'bg-purple-50',
    },
    {
      title: 'العملاء',
      value: stats.totalCustomers.toString(),
      icon: Users,
      color: 'bg-indigo-500',
      bgLight: 'bg-indigo-50',
    },
  ];

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600"></div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-3xl font-bold text-gray-900">لوحة التحكم</h1>
        <div className="text-sm text-gray-500">
          {new Date().toLocaleDateString('ar-IQ', {
            weekday: 'long',
            year: 'numeric',
            month: 'long',
            day: 'numeric',
          })}
        </div>
      </div>

      {stats.lowStockProducts > 0 && (
        <div className="bg-yellow-50 border-r-4 border-yellow-500 p-4 rounded-lg flex items-center gap-3">
          <AlertTriangle className="w-6 h-6 text-yellow-600 flex-shrink-0" />
          <div>
            <p className="font-semibold text-yellow-900">تنبيه: نقص في المخزون</p>
            <p className="text-sm text-yellow-700">
              يوجد {stats.lowStockProducts} منتج بحاجة لإعادة التوريد
            </p>
          </div>
        </div>
      )}

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {statCards.map((card) => (
          <div key={card.title} className="bg-white rounded-xl shadow-sm p-6 border border-gray-100">
            <div className="flex items-center justify-between mb-4">
              <div className={`${card.bgLight} p-3 rounded-lg`}>
                <card.icon className={`w-6 h-6 ${card.color.replace('bg-', 'text-')}`} />
              </div>
            </div>
            <h3 className="text-gray-600 text-sm font-medium mb-1">{card.title}</h3>
            <p className="text-2xl font-bold text-gray-900">{card.value}</p>
          </div>
        ))}
      </div>

      <div className="bg-white rounded-xl shadow-sm p-6 border border-gray-100">
        <h2 className="text-xl font-bold text-gray-900 mb-4">نظرة عامة</h2>
        <div className="space-y-4">
          <div className="flex items-center justify-between py-3 border-b border-gray-100">
            <span className="text-gray-600">حالة النظام</span>
            <span className="px-3 py-1 bg-green-100 text-green-700 rounded-full text-sm font-medium">
              متصل
            </span>
          </div>
          <div className="flex items-center justify-between py-3 border-b border-gray-100">
            <span className="text-gray-600">آخر عملية بيع</span>
            <span className="text-gray-900 font-medium">
              {new Date().toLocaleTimeString('ar-IQ', {
                hour: '2-digit',
                minute: '2-digit',
              })}
            </span>
          </div>
          <div className="flex items-center justify-between py-3">
            <span className="text-gray-600">الفرع النشط</span>
            <span className="text-gray-900 font-medium">الفرع الرئيسي</span>
          </div>
        </div>
      </div>
    </div>
  );
}
